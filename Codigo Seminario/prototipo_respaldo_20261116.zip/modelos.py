"""Formatos de datos que intercambian los componentes del sistema.

Cada componente lee y escribe estos modelos, de modo que puedan probarse por separado
y que cada ejecución quede guardada como evidencia (RNF04).
"""
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

NombreSesion = Literal["A", "B", "anonima"]


# ---------- Alcance autorizado (RF01) ----------
class CuentaPrueba(BaseModel):
    nombre: Literal["A", "B"]
    correo: str
    clave: str


class Alcance(BaseModel):
    """Lista cerrada de lo que el sistema puede tocar. Se lee de un archivo y no se modifica durante la ejecución."""
    aplicacion: str
    url_base: str                              # p. ej. http://localhost:3000
    prefijos_api: list[str]                    # solo se analizan peticiones a estas rutas
    pantallas: list[str]                       # rutas de la interfaz que recorre el navegador
    cuentas: list[CuentaPrueba]
    proxy: str = "http://127.0.0.1:8080"


# ---------- Salida del Explorador ----------
class ObjetoSembrado(BaseModel):
    """Objeto creado por el sistema en una cuenta; su dueño se conoce por construcción."""
    cuenta: Literal["A", "B"]
    tipo: str                                  # canasta, direccion, tarjeta...
    id: str
    canario: str | None = None                 # valor único sembrado, si el objeto lo tiene
    endpoint: str | None = None                # plantilla que lo entrega, p. ej. /rest/basket/{id}.
                                               # Necesaria porque el mismo id puede ser de objetos distintos


class CuentaExplorada(BaseModel):
    nombre: Literal["A", "B"]
    correo: str
    id_usuario: str                            # la clave y el token no se guardan


class PeticionCapturada(BaseModel):
    id: str                                    # p. ej. A-0007
    sesion: NombreSesion
    host: str = ""                             # p. ej. localhost:3000, para descartar tráfico ajeno al alcance
    metodo: str
    ruta: str                                  # sin la consulta
    consulta: str = ""                         # texto después de '?'
    cuerpo_peticion: str = ""
    estado: int
    tipo_contenido: str = ""
    cuerpo_respuesta: str = ""
    autenticada: bool


class ResultadoExploracion(BaseModel):
    ejecucion: str                             # identificador de la ejecución, p. ej. 20261114_1530
    fecha: datetime
    aplicacion: str
    cuentas: list[CuentaExplorada]
    inventario: list[ObjetoSembrado]
    peticiones: list[PeticionCapturada]
    descartadas: dict[str, int] = Field(default_factory=dict)  # motivo -> cantidad (RF10)


# ---------- Salida del Analista ----------
Ubicacion = Literal["ruta", "consulta", "cuerpo"]


class Endpoint(BaseModel):
    """Grupo de peticiones con el mismo método, plantilla de ruta y parámetros de consulta (RF04)."""
    clave: str                                 # p. ej. "GET /rest/basket/{id}"
    metodo: str
    plantilla: str                             # ruta con los identificadores reemplazados por {id}
    parametros_consulta: list[str] = Field(default_factory=list)
    peticiones: list[str]                      # ids de las PeticionCapturada del grupo
    sesiones: list[NombreSesion]
    autenticada: bool                          # al menos una petición del grupo iba autenticada


class Candidato(BaseModel):
    """Parámetro de una petición que podría identificar un objeto. Los pasos 2 a 4 lo completan."""
    peticion: str                              # id de la PeticionCapturada
    endpoint: str                              # clave del Endpoint
    sesion: NombreSesion
    parametro: str                             # nombre (p. ej. "BasketId") o posición en la ruta
    valor: str
    ubicacion: Ubicacion
    decidido_por: Literal["inventario", "llm", "regla"] | None = None
    es_identificador: bool | None = None
    visibilidad: Literal["privado", "publico"] | None = None
    cuenta_duena: Literal["A", "B", "desconocida"] | None = None
    objeto: str | None = None                  # tipo de objeto del inventario, si corresponde
    justificacion: str = ""


class Hipotesis(BaseModel):
    """Prueba que el Agente de Remediación / Validación debe hacer: repetir una petición con otra sesión."""
    id: str                                    # p. ej. H-001
    tipo: Literal["horizontal", "sin_sesion"]  # B con objetos de A, o sin autenticación
    endpoint: str
    peticion_origen: str                       # petición original, hecha por el dueño
    sesion_origen: Literal["A", "B"]
    sesion_prueba: NombreSesion                # sesión con la que se repetirá
    cuenta_duena: Literal["A", "B", "desconocida"]
    parametro: str | None = None               # None en endpoints sin identificador (p. ej. listas propias)
    valor: str | None = None
    ubicacion: Ubicacion | None = None
    objeto: str | None = None
    origen: Literal["inventario", "llm", "regla"]  # quién decidió que el objeto es privado
    # Cómo confirmará la fuga el Juez determinista. "sin_verificacion": el resultado quedará como dudoso
    # hasta el Juez con LLM (Proyecto de Título).
    verificacion: Literal["canario", "inventario", "sin_verificacion"]
    canario: str | None = None                 # valor a buscar en la respuesta, si verificacion = canario
    marca_dueno: str | None = None             # id o correo del dueño a buscar, si verificacion = inventario


class ResultadoAnalisis(BaseModel):
    ejecucion: str                             # misma ejecución del Explorador
    fecha: datetime
    modo: Literal["solo_reglas", "reglas_llm"] # "solo_reglas" es la variante de la hipótesis H3
    modelo: str | None = None                  # p. ej. gemma4:e4b; None en modo solo reglas
    endpoints: list[Endpoint]
    candidatos: list[Candidato] = Field(default_factory=list)
    hipotesis: list[Hipotesis] = Field(default_factory=list)
    omitidas: dict[str, int] = Field(default_factory=dict)  # motivo -> cantidad de pruebas no generadas
    consultas_llm: int = 0
    duracion_s: float = 0.0
